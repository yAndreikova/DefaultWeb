# DefaultWeb _ Working Directory
This repository is the default web project that I use in some training courses. 
If you are taking one of my courses, this is the right place to be for the default web project. 

If you are looking for a fancy web template, there are much better resources available to you via a simple search for "free bootstrap/html5 website templates"

Also note: This is not the basic setup. This code has been modified during the production of one of my courses.  If you want the bare starte, make sure to actually use the DefaultWeb project.
